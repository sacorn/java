/**
 * Name: Salvador Cornejo
 * Email: scorne18@calstatela.edu
 * Class: CS2013
 * Assignment: 06
 * Purpose: We are given number of rows and columns and we need to use link list
 * to make create nodes and attach them either right or down. so we will have a nxm
 * link list.
 */

package hw06;

public class main {

	public static void main(String[] args) {
		Array2D a = new Array2D();
		System.out.println(a.colSize());
		System.out.println(a.rowSize());
		a.addFirstCol();
		System.out.println(a.colSize());
		System.out.println(a.rowSize());
		a.addFirstCol();
		a.addFirstCol();
		System.out.println(a.colSize());
		System.out.println(a.rowSize());
		a.addFirstRow();
		System.out.println(a.colSize());
		System.out.println(a.rowSize());
		a.insertCol(3);
		System.out.println("column: " + a.colSize());
		System.out.println("row: " + a.rowSize());
		a.set(2, 4, "hi");
		a.set(2, 2, "hi");
		a.set(1, 4, "hey");
		a.print();
		a.deleteCol(4);
		a.print();
		//Gets an error after this line
		Array2D b = new Array2D(2,3);
		System.out.println("this is B:");
		b.print();
		
	}

}
