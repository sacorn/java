/**
 * Name: Salvador Cornejo
 * Email: scorne18@calstatela.edu
 * Class: CS2013
 * Assignment: 02
 * 
 * 
 * Status: Incomplete
 */

package hw02;

public class main {
	public void testMethod1() {
		Inventory o = new Inventory();
		
		
	}

}
