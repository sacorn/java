/**
 * Name: Salvador Cornejo
 * Email: scorne18@calstatela.edu
 * Class: CS2013
 * Assignment: 03
 * Purpose: This program works with generics.
 */
package hw03;

import java.util.ArrayList;


// It's 11:53 and i know what i want to do but java isnt having it with the syntax im giving it and im freaking out how to correctly write them in 7 minutes :(
public class main {

	public static void main(String[] args) {
		MyArray<String> arr = {"hello"};
		MyArray<Integer> arr2 = new MyArray<Integer>(2);
		arr2[1, 2];
		
		System.out.println(arr2.max());

	}

}
